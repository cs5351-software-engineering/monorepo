def calculate_grade(score):
    if score >= 90:
        grade = "A"
    elif score >= 80:
        grade = "B"
    elif score >= 70:
        grade = "C"
    elif score >= 60:
        grade = "D"
    else:
        grade = "F"
    
    if score >= 60 and score < 70:
        print("You barely passed!")
    elif score < 60:
        print("You failed!")
    
    return grade

def calculate_discount(price, is_vip):
    discount = 0
    if price > 100 and is_vip == True:
        discount = 20
    elif price > 100:
        discount = 10
    elif price > 50:
        discount = 5
    
    return discount

def main():
    score = float(input("Enter your score: "))
    grade = calculate_grade(score)
    print(f"Your grade is: {grade}")

    price = float(input("Enter the price: "))
    is_vip = input("Are you a VIP customer? (y/n): ").lower() == "y"
    discount = calculate_discount(price, is_vip)
    print(f"Discount applied: {discount}%")

if __name__ == "__main__":
    main()