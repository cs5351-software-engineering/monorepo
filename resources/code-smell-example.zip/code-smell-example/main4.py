

def foo(x):
    i = 0
    arr = [1, 2]
    y = arr[3]
    return x

