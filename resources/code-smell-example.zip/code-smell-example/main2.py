import urllib3
http = urllib3.PoolManager()
r = http.request('GET', 'https://www.google.com/robots.txt')
print(r.data)

