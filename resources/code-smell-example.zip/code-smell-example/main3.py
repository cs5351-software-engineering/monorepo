# Function to calculate the factorial of a number using nonstop recursion
def factorial(n):
    return n * factorial(n-1)

# Unused variable in this code
result = factorial(5)

x = 42

print("Factorial of 5 is:", result)




