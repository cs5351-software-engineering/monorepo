from dataclasses import dataclass


@dataclass
class Ast:
    pass
